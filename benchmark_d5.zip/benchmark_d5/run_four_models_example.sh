#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"

ROOT_DIR="${ROOT_DIR:-/home/featurize/data/vox}"
OUT_ROOT="${OUT_ROOT:-$SCRIPT_DIR/../benchmark_results}"
DEVICE="${DEVICE:-0}"
STRIDE="${STRIDE:-3}"
GAPS=(3 5 7)

SINGLE_DIR="${SINGLE_DIR:-/home/featurize/work/CFTE}"
NOREFINE_DIR="${NOREFINE_DIR:-/home/featurize/work/CFTE_NoRefine}"
FIXEDCMR_DIR="${FIXEDCMR_DIR:-/home/featurize/work/CFTE_Refined_FixedCMR}"
ADAPTIVE_DIR="${ADAPTIVE_DIR:-/home/featurize/work/CFTE_Refined_AdaptiveCMR}"

# Optional output controls. Formal CSV evaluation is always performed.
SAVE_SAMPLE_IMAGES="${SAVE_SAMPLE_IMAGES:-0}"
SAVE_VIDEO_PANELS="${SAVE_VIDEO_PANELS:-0}"
MAX_SAVED_IMAGES="${MAX_SAVED_IMAGES:-50}"
VIDEO_PANEL_MAX_SAMPLES="${VIDEO_PANEL_MAX_SAMPLES:-12}"

export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

latest_checkpoint() {
  local project_dir="$1"
  local found
  found="$(
    find "$project_dir" -type f -name '*-checkpoint.pth.tar' \
      -printf '%T@ %p\n' 2>/dev/null \
      | sort -nr \
      | head -n 1 \
      | cut -d' ' -f2-
  )"
  if [[ -z "$found" ]]; then
    echo "No checkpoint found under: $project_dir" >&2
    exit 1
  fi
  printf '%s\n' "$found"
}

# Explicit environment-variable paths take precedence. Otherwise use the most
# recently modified checkpoint found under each project directory.
SINGLE_CKPT="${SINGLE_CKPT:-$(latest_checkpoint "$SINGLE_DIR")}"
NOREFINE_CKPT="${NOREFINE_CKPT:-$(latest_checkpoint "$NOREFINE_DIR")}"
FIXEDCMR_CKPT="${FIXEDCMR_CKPT:-$(latest_checkpoint "$FIXEDCMR_DIR")}"
ADAPTIVE_CKPT="${ADAPTIVE_CKPT:-$(latest_checkpoint "$ADAPTIVE_DIR")}"

echo "Dataset:       $ROOT_DIR"
echo "Output:        $OUT_ROOT"
echo "CUDA device:   $DEVICE"
echo "Single CKPT:   $SINGLE_CKPT"
echo "NoRefine CKPT: $NOREFINE_CKPT"
echo "Fixed CKPT:    $FIXEDCMR_CKPT"
echo "Adaptive CKPT: $ADAPTIVE_CKPT"

"$PYTHON_BIN" "$SCRIPT_DIR/preflight_check.py" \
  --single_dir "$SINGLE_DIR" \
  --single_checkpoint "$SINGLE_CKPT" \
  --norefine_dir "$NOREFINE_DIR" \
  --norefine_checkpoint "$NOREFINE_CKPT" \
  --fixedcmr_dir "$FIXEDCMR_DIR" \
  --fixedcmr_checkpoint "$FIXEDCMR_CKPT" \
  --adaptive_dir "$ADAPTIVE_DIR" \
  --adaptive_checkpoint "$ADAPTIVE_CKPT"

ALL_RESULT_CSVS=()

run_method() {
  local script_name="$1"
  local project_dir="$2"
  local checkpoint="$3"
  local output_csv="$4"
  local image_dir="$5"
  local panel_dir="$6"
  shift 6

  local args=(
    "$PYTHON_BIN" "$SCRIPT_DIR/$script_name"
    --project_dir "$project_dir"
    --config "$project_dir/config/vox-256.yaml"
    --checkpoint "$checkpoint"
    --root_dir "$ROOT_DIR"
    --test_csv "$INDEX_CSV"
    --output_csv "$output_csv"
    --device "$DEVICE"
    --require_lpips
    "$@"
  )

  if [[ "$SAVE_SAMPLE_IMAGES" == "1" ]]; then
    args+=(--save_images "$image_dir" --max_saved_images "$MAX_SAVED_IMAGES")
  fi
  if [[ "$SAVE_VIDEO_PANELS" == "1" ]]; then
    args+=(
      --save_video_panels "$panel_dir"
      --video_panel_max_samples "$VIDEO_PANEL_MAX_SAMPLES"
    )
  fi

  "${args[@]}"
}

for GAP in "${GAPS[@]}"; do
  OUT_DIR="$OUT_ROOT/gap${GAP}_stride${STRIDE}"
  TABLE_DIR="$OUT_DIR/tables"
  INDEX_CSV="$TABLE_DIR/test_triplets_gap${GAP}_stride${STRIDE}.csv"

  mkdir -p "$TABLE_DIR"

  # Each temporal gap has its own valid target-frame set. Within one gap, all
  # four methods use exactly the same CSV rows.
  "$PYTHON_BIN" "$SCRIPT_DIR/make_test_triplets_gap3_stride3.py" \
    --root_dir "$ROOT_DIR" \
    --gap "$GAP" \
    --stride "$STRIDE" \
    --output_csv "$INDEX_CSV"

  run_method \
    test_single_cfte.py \
    "$SINGLE_DIR" "$SINGLE_CKPT" \
    "$TABLE_DIR/results_single_cfte.csv" \
    "$OUT_DIR/predictions/single_cfte" \
    "$OUT_DIR/video_panels"

  run_method \
    test_norefine_twoframe.py \
    "$NOREFINE_DIR" "$NOREFINE_CKPT" \
    "$TABLE_DIR/results_norefine.csv" \
    "$OUT_DIR/predictions/norefine" \
    "$OUT_DIR/video_panels"

  run_method \
    test_fixedcmr_twoframe.py \
    "$FIXEDCMR_DIR" "$FIXEDCMR_CKPT" \
    "$TABLE_DIR/results_fixedcmr.csv" \
    "$OUT_DIR/predictions/fixedcmr" \
    "$OUT_DIR/video_panels"

  run_method \
    test_adaptivecmr_twoframe.py \
    "$ADAPTIVE_DIR" "$ADAPTIVE_CKPT" \
    "$TABLE_DIR/results_adaptivecmr.csv" \
    "$OUT_DIR/predictions/adaptivecmr" \
    "$OUT_DIR/video_panels"

  "$PYTHON_BIN" "$SCRIPT_DIR/merge_results.py" \
    --inputs \
      "$TABLE_DIR/results_single_cfte.csv" \
      "$TABLE_DIR/results_norefine.csv" \
      "$TABLE_DIR/results_fixedcmr.csv" \
      "$TABLE_DIR/results_adaptivecmr.csv" \
    --output_dir "$TABLE_DIR"

  "$PYTHON_BIN" "$SCRIPT_DIR/4Method_Analysis_with_BPP_Superposed.py" \
    --single "$TABLE_DIR/results_single_cfte.csv" \
    --norefine "$TABLE_DIR/results_norefine.csv" \
    --fixedcmr "$TABLE_DIR/results_fixedcmr.csv" \
    --adaptive "$TABLE_DIR/results_adaptivecmr.csv" \
    --outdir "$OUT_DIR/four_method_summary"

  ALL_RESULT_CSVS+=(
    "$TABLE_DIR/results_single_cfte.csv"
    "$TABLE_DIR/results_norefine.csv"
    "$TABLE_DIR/results_fixedcmr.csv"
    "$TABLE_DIR/results_adaptivecmr.csv"
  )
done

"$PYTHON_BIN" "$SCRIPT_DIR/merge_results.py" \
  --inputs "${ALL_RESULT_CSVS[@]}" \
  --output_dir "$OUT_ROOT/all_gaps_tables"

echo "Benchmark completed: $OUT_ROOT"
